extends Node
class_name GridEvent

@onready var config: EntityConfig = get_parent() as EntityConfig
@onready var runner: EventRunner = $"../EventRunner"

#===============================================================================

func start(caller: GridEntity):

	if runner == null:
		return

	runner.start(self, caller)

#===============================================================================

func stop():

	if runner != null:
		runner.finish()

#===============================================================================

func is_running() -> bool:

	if runner == null:
		return false

	return runner.is_running()

#===============================================================================

func can_execute(_entity: GridEntity) -> bool:
	return true

func execute(_entity: GridEntity):
	pass

#===============================================================================

func is_enabled() -> bool:
	return config.enabled

func get_trigger_mode() -> EntityConfig.TriggerMode:
	return config.trigger_mode

func is_parallel() -> bool:
	return config.trigger_mode == EntityConfig.TriggerMode.PARALLEL

func is_autorun() -> bool:
	return config.trigger_mode == EntityConfig.TriggerMode.AUTORUN
