extends Node
class_name EventRunner

var commands: Array[EventCommand] = []

var current_index := 0

var running := false

var context: EventContext

var scheduler: EventScheduler

#===============================================================================

func collect_commands():

	commands.clear()

	for child in get_children():

		if child is EventCommand:
			commands.append(child)

#===============================================================================

func start(
	event: GridEvent,
	caller: GridEntity
):

	if running:
		return

	collect_commands()

	if commands.is_empty():
		return

	scheduler = EventScheduler.new()
	context = EventContext.new()

	context.runner = self
	context.event = event
	context.entity = event.get_parent().get_node("GridEntity")
	context.caller = caller

	running = true
	current_index = 0

	commands[current_index].start(self)

#===============================================================================

func next():

	if !running:
		return

	current_index += 1

	if current_index >= commands.size():

		finish()
		return

	commands[current_index].start(self)

#===============================================================================

func finish():

	if !running:
		return

	running = false

	scheduler.finish(self)

#===============================================================================

func is_running() -> bool:
	return running

#===============================================================================

func get_context() -> EventContext:
	return context
