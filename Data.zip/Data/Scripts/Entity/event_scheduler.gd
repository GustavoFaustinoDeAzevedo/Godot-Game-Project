extends Node
class_name EventScheduler

@export var grid_world: GridWorld

var current_runner: EventRunner

var queue: Array[String]

var parallel_runners: Array[EventRunner]

#===============================================================================

func _ready():

	if grid_world == null:
		grid_world = get_tree().get_first_node_in_group("grid_world")

	assert(grid_world != null)

	grid_world.entity_entered.connect(_on_entity_entered)
	grid_world.entity_left.connect(_on_entity_left)
	grid_world.entity_interacted.connect(_on_entity_interacted)

#===============================================================================

func _on_entity_entered(
	entity: GridEntity,
	cell: Vector3i
):

	_dispatch(
		entity,
		cell,
		EntityConfig.TriggerMode.ENTER
	)

#===============================================================================

func _on_entity_left(
	entity: GridEntity,
	cell: Vector3i
):

	_dispatch(
		entity,
		cell,
		EntityConfig.TriggerMode.EXIT
	)

#===============================================================================

func _on_entity_interacted(
	entity: GridEntity,
	cell: Vector3i
):

	_dispatch(
		entity,
		cell,
		EntityConfig.TriggerMode.INTERACT
	)

#===============================================================================

func _dispatch(
	caller: GridEntity,
	cell: Vector3i,
	mode: EntityConfig.TriggerMode
):

	for event: GridEvent in grid_world.get_events(cell):

		var config := event.get_parent() as EntityConfig

		if config == null:
			continue

		if !config.enabled:
			continue

		if config.trigger_mode != mode:
			continue

		if !event.can_execute(caller):
			continue

		request(
			event,
			caller
		)

#===============================================================================

func request(
	event: GridEvent,
	caller: GridEntity
):
	event.start(caller)
	
#===============================================================================

func finish(
	runner: EventRunner
):

	if runner == current_runner:
		current_runner = null

	parallel_runners.erase(runner)
